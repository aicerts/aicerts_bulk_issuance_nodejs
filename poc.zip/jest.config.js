module.exports = {
    testMatch: [
        '<rootDir>/test/*.test.js'
    ],
    testPathIgnorePatterns: ['<rootDir>/node_modules/']
}